#include "mbed.h"

DigitalOut led1(PA_5);

int main()
{
    if (led1.is_connected()) {
        printf("led1 is initialized and connected!\n\r");
    }
    
    while(1)
    {
        //led1 = 1;
        led1.write(1);
        printf("led1 status ---> %d\n", led1.read());
        wait(1.0);
        
        
        
        //led1 = 0;
        led1.write(0);
        printf("led1 status ---> %d\n", (int)led1);
        wait(1.0);
    }
}