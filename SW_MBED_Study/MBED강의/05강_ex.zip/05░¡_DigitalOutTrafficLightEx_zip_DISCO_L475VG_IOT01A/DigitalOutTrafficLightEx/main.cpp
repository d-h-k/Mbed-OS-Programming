#include "mbed.h"

DigitalOut ledR(D2);
DigitalOut ledY(D3);
DigitalOut ledG(D4);

int main()
{
    while(1)
    {
        
        ledR = 1;
        ledY = 0;
        ledG = 0;
        wait(5);
        
        ledR = 0;
        ledY = 0;
        ledG = 1;
        wait(5);
        
        ledR = 0;
        ledY = 1;
        ledG = 1;
        wait(2);
        
        }
        
    }
