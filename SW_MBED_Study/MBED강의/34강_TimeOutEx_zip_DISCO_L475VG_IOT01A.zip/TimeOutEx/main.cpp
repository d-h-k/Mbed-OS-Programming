#include "mbed.h"

DigitalOut led_red_d2(D2);
DigitalOut led_gre_d3(D3);

Ticker tic1;
Timeout to1;
Timer timer1;

Ticker tic2;
Timeout to2;

AnalogIn cds_sensor(A0);

void ledRedD2Fun()
{
    led_red_d2 = !led_red_d2;
}

void ledGerD3Fun()
{
    led_gre_d3 = 0;
    timer1.stop();
    printf("timer1 stop!!\n");
    printf("timer1.read() --> %.2f SEC \n", timer1.read());
}

void getCdsValue()
{
    printf("cds_sensor value ---> %.2f\n", cds_sensor.read());
}

void getCdsValueFun()
{
    printf("Time Out!!\n");
    tic2.attach(getCdsValue, 3);
    
}

int main()
{
    led_gre_d3 = 1;
    
    tic1.attach(ledRedD2Fun, 1);
    
    to1.attach(ledGerD3Fun, 5);
    timer1.start();
    printf("timer1 start!!\n");
    
    to2.attach(getCdsValueFun, 10);
    
    while(1)
    {
        
    }
    
}