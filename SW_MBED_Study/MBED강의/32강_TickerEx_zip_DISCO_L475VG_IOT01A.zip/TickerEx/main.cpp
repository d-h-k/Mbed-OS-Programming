#include "mbed.h"
#include "DHT.h"

DigitalOut led_red_d2(D2);
DHT temp_humi_sensor(D4, DHT11);
AnalogIn cds_sensor(A0);

Ticker tic1, tic2, tic3;

void blinkLed(){
    led_red_d2 = !led_red_d2;
    printf("led_red_d2 STATUS ------------> %d\n", led_red_d2.read());
}

void getTempHumi(){
    int sensorErrorResult = temp_humi_sensor.readData();
    if(sensorErrorResult == 0)
    {
        // NO ERROR
        // 온도
        printf("No Error \n");
        printf("Temperature(C) ---> %.2fC\n", temp_humi_sensor.ReadTemperature(CELCIUS));       // 섭씨(C)
        printf("Temperature(F) ---> %.2fF \n", temp_humi_sensor.ReadTemperature(FARENHEIT));    // 화씨(F)
        printf("Temperature(K) ---> %.2fK \n", temp_humi_sensor.ReadTemperature(KELVIN));       // 칼빈(K)
        
        //습도
        printf("Humidity(%%) ---> %.2f%%\n", temp_humi_sensor.ReadHumidity());       // 습도
        printf("Dew Point ---> %.2f\n", temp_humi_sensor.CalcdewPoint(temp_humi_sensor.ReadTemperature(CELCIUS), temp_humi_sensor.ReadHumidity()));       // 이슬점(노점)
    }
    else
    {
        // ERROR
        printf("Error \n");
        printf("Error Code ---> %d \n", sensorErrorResult);
    }
}

void getLight(){
    printf("cds_sensor value = %.2f \n", cds_sensor.read());
}

int main()
{
    tic1.attach(blinkLed, 0.5);
    tic2.attach(getTempHumi, 5);
    tic3.attach(getLight, 2);
    
    while(1)
    {
        /*
        led_red_d2 = !led_red_d2;
        wait(0.5);
        
        int sensorErrorResult = temp_humi_sensor.readData();
        if(sensorErrorResult == 0)
        {
            // NO ERROR
            // 온도
            printf("No Error \n");
            printf("Temperature(C) ---> %.2fC\n", temp_humi_sensor.ReadTemperature(CELCIUS));       // 섭씨(C)
            printf("Temperature(F) ---> %.2fF \n", temp_humi_sensor.ReadTemperature(FARENHEIT));    // 화씨(F)
            printf("Temperature(K) ---> %.2fK \n", temp_humi_sensor.ReadTemperature(KELVIN));       // 칼빈(K)
            
            //습도
            printf("Humidity(%%) ---> %.2f%%\n", temp_humi_sensor.ReadHumidity());       // 습도
            printf("Dew Point ---> %.2f\n", temp_humi_sensor.CalcdewPoint(temp_humi_sensor.ReadTemperature(CELCIUS), temp_humi_sensor.ReadHumidity()));       // 이슬점(노점)
        }
        else
        {
            // ERROR
            printf("Error \n");
            printf("Error Code ---> %d \n", sensorErrorResult);
        }
        wait(5);
        
        printf("cds_sensor value ---> %f \n", cds_sensor.read());
        wait(2);
        */
    }
    
}