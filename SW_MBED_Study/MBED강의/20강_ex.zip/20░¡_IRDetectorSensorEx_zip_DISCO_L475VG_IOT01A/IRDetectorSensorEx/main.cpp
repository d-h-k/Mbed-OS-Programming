#include "mbed.h"

DigitalIn ir_sensor(D5);
BusOut leds(D2, D3, D14);

int main()
{
    leds = 1;
    
    while(1)
    {
        //printf("ir sensor value ---> %d \n", ir_sensor.read());
        //wait(1);
        
        int value = ir_sensor.read();       // 1: non block, 0:block
        printf("ir sensor value ---> %d \n", value);
        
        if(value == 0)  //block
        {
            leds = 6;
            wait(1);
        }
        else
        {
            leds = 1;
        }
    }
    
}