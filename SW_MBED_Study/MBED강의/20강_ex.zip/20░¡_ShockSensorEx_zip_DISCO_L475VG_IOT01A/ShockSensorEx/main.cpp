#include "mbed.h"

DigitalIn shock_sensor(D15);
DigitalOut vibrator(D14);
BusOut leds(D2, D3);

int main()
{
    vibrator = 0;
    leds = 0;
    
    while(1)
    {
        
        int value = shock_sensor.read();
        printf("shock sensorvalue ---> %d \n", value);
        vibrator = value;
        
        if(value == 0) leds = 1;
        else leds = 2;
        
        if(value == 1) wait(1);
        
    }
}