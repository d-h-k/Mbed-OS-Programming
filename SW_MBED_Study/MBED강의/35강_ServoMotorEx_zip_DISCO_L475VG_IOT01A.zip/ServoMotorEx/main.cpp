#include "mbed.h"
#include "Servo.h"

Servo myservo(D3);
AnalogIn poten(A1);

Ticker tic1;

Serial pc(USBTX, USBRX, 9600);

void controlServo()
{
    float value = poten.read();
    printf("value ---> %f\n", value);
    myservo.write(value);
}

int main()
{
    // void calibrate(float range = 0.0005, float degrees = 45.0); 
    //myservo.calibrate(0.0005, 45); // Default
    myservo.calibrate(0.001, 90);
    
    //tic1.attach(controlServo, 0.2);
    
    while(1)
    {
        /*
        for(float p = 0.0f; p < 1; p += 0.1)
        {
            myservo.write(p);
            wait(0.2);
        }
        
        for(float p = 1.0f; p > 0; p -= 0.1)
        {
            myservo.write(p);
            wait(0.2);
        }
        */
        
        /*
        float value = poten.read();
        printf("value ---> %f\n", value);
        myservo.write(value);
        wait(0.2);
        */
        
        if(pc.readable())
        {
            
            char c = pc.getc();
            
            if(c == '0') myservo.write(0);
            else if(c == '1') myservo.write(1);
            
            pc.putc(c);
            pc.putc('\n');
            
        }
        
    }
    
}