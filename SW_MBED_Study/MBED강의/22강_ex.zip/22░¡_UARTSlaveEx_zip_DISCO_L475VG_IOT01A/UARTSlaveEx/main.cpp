#include "mbed.h"
#include "cstdlib"

Serial pc(USBTX, USBRX);
Serial master(PC_1, PC_0);

//BusOut leds(D2, D3, D4);

PwmOut aLedR(D2);

int main()
{
    //leds = 0;
    
    while(1)
    {
        /*
        if(master.readable())
        {
            char c = master.getc();
            pc.putc(c);
            pc.putc('\n');
        }
        */
        
        /*
        if(master.readable())
        {
            char c = master.getc();
            pc.putc(c);
            pc.putc('\n');
            
            if(c == 'r')leds = 1;
            else if(c == 'g')leds = 2;
            else if(c == 'b')leds = 4;
        }*/
        
        
        if(master.readable())
        {
            char buffer[50];
            master.gets(buffer, 9);
            
            pc.printf("buffer ---> %s \n", buffer); // 0.162547
            aLedR.write(atof(buffer));
        }
    }
    
}