#include "mbed.h"

Serial pc(USBTX, USBRX);
Serial slave(PC_1, PC_0);

AnalogIn cds_sensor(A0);

int main()
{
    
    while(1)
    {
        /*
        if(pc.readable())
        {
            char c = pc.getc();
            slave.putc(c);
        }
        */
        
        /*
        float value = cds_sensor.read();
        pc.printf("value ---> %f \n", value);
        
        char data = 'b';
        if(value > 0.7f) data = 'r';
        else if(value > 0.4f) data = 'g';
        else data = 'b';
        
        slave.putc(data);
        wait(1);
        */
        
        float value = cds_sensor.read();
        pc.printf("value ---> %f \n", value);
        
        char buffer[50];
        sprintf(buffer, "%f", value);
        slave.puts(buffer);
        wait(1);
        
    }
    
}