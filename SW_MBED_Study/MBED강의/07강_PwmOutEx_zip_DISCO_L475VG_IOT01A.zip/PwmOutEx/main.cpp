#include "mbed.h"

PwmOut pwmLed1(LED1);
PwmOut pwmLed3(LED3);
PwmOut pwmD3(D3);

int main()
{
    
    pwmLed1.write(0);
    pwmLed3.write(1);
    pwmD3.write(0);
    
    while(1)
    {
        for(float f = 0.0f; f < 1.0f; f += 0.05f)
        {
            pwmLed1.write(f);
            pwmLed3.write(1 - f);
            pwmD3.write(f);
            
            printf("pwmLed1 voltage ------------> %f \n", pwmLed1.read());
            printf("pwmLed3 voltage ---> %f \n", pwmLed3.read());
            printf("pwmD3 voltage > %f \n", pwmD3.read());
            
            wait(0.1);
            
        }
            
        for(float f = 0.0f; f < 1.0f; f += 0.05f)
        {
            pwmLed1.write(1 - f);
            pwmLed3.write(f);
            pwmD3.write(1 - f);
            
            printf("pwmLed1 voltage ------------> %f \n", pwmLed1.read());
            printf("pwmLed3 voltage ---> %f \n", pwmLed3.read());
            printf("pwmD3 voltage > %f \n", pwmD3.read());
            
            wait(0.1);
            
        }
        
    }
    
}