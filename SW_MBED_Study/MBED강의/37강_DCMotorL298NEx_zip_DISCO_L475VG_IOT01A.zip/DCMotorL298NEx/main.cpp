#include "mbed.h"

PwmOut ENA(D10);    // EnalbeA(모터A)
PwmOut ENB(D5);     // EnalbeB(모터B)

DigitalOut IN1(D9); //모터A
DigitalOut IN2(D8); //모터A

DigitalOut IN3(D7); //모터B
DigitalOut IN4(D6); //모터B

float mSpeed = 0.5f;

int main()
{
    
    while(1)
    {
        /*
        //정방향
        ENA = mSpeed;       // 모터A 스피드
        ENB = mSpeed;       // 모터B 스피드
        
        // 모터 A
        IN1 = 1;
        IN2 = 0;
        
        // 모터 B
        IN3 = 1;
        IN4 = 0;
        
        wait(5);
        
        //역방향
        ENA = mSpeed;       // 모터A 스피드
        ENB = mSpeed;       // 모터B 스피드
        
        // 모터 A
        IN1 = 0;
        IN2 = 1;
        
        // 모터 B
        IN3 = 0;
        IN4 = 1;
        
        wait(5);
        */
        
        IN1 = 1;
        IN2 = 0;
        
        for(float s = 0.0f; s < 1.0f; s += 0.01f)
        {
            ENA = s;
            wait(0.05);
        }
        
        IN1 = 0;
        IN2 = 0;
        wait(5);
        
    }
    
}
