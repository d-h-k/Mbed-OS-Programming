#include "mbed.h"
#include "Adafruit_SSD1306.h"
#include "DHT.h"

I2C i2c_oled(A4, A5); //sda, scl
Adafruit_SSD1306_I2c oled(i2c_oled, NC, 0x78, 64, 128);

DHT temp_humi_sensor(D15, DHT11);

int main()
{
    /*
    oled.clearDisplay();
    oled.setTextSize(1);
    oled.setTextCursor(0, 10);
    oled.writeChar('H');
    oled.writeChar('e');
    oled.writeChar('l');
    oled.writeChar('l');
    oled.writeChar('o');
    
    oled.setTextSize(2);
    oled.setTextCursor(0, 20);
    oled.printf("Hello %d", 2);
    
    oled.display();
    */
    
    int sensorErrorResult = 0;
    
    while(1)
    {
        
        oled.clearDisplay();
        oled.setTextSize(1);
        oled.setTextCursor(0, 10);
        
        sensorErrorResult = temp_humi_sensor.readData();
        if(sensorErrorResult == 0)
        {
            // NO ERROR
            // 온도
            printf("No Error \n");
            printf("Temperature(C) ---> %.2fC\n", temp_humi_sensor.ReadTemperature(CELCIUS));       // 섭씨(C)
            printf("Temperature(F) ---> %.2fF \n", temp_humi_sensor.ReadTemperature(FARENHEIT));    // 화씨(F)
            printf("Temperature(K) ---> %.2fK \n", temp_humi_sensor.ReadTemperature(KELVIN));       // 칼빈(K)
            
            //습도
            printf("Humidity(%%) ---> %.2f%%\n", temp_humi_sensor.ReadHumidity());       // 습도
            printf("Dew Point ---> %.2f\n", temp_humi_sensor.CalcdewPoint(temp_humi_sensor.ReadTemperature(CELCIUS), temp_humi_sensor.ReadHumidity()));       // 이슬점(노점)
    
            oled.printf("Temp(C) : %.2fC\n", temp_humi_sensor.ReadTemperature(CELCIUS));
            oled.printf("Humi(%%) : %.2fC\n", temp_humi_sensor.ReadHumidity());
            oled.printf("DPoint(C) : %.2fC\n", temp_humi_sensor.CalcdewPoint(temp_humi_sensor.ReadTemperature(CELCIUS), temp_humi_sensor.ReadHumidity()));
        }
        else
        {
            // ERROR
            printf("Error \n");
            printf("Error Code ---> %d \n", sensorErrorResult);
            
            oled.printf("Error \n");
        }
        
        oled.display();
        wait(10);
        
    }
    
}