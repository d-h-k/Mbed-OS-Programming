#include "mbed.h"
#include "DHT.h"

DHT temp_humi_sensor(D15, DHT11);
DigitalOut ledR(D2);
DigitalOut ledB(D3);

void setLedStatus(DigitalOut led, int status)
{
    led = status;
}

int main()
{
    int sensorErrorResult = 0;
    setLedStatus(ledR, 0);
    setLedStatus(ledB, 0);
    
    wait(5);
    
    while(1)
    {
        
        sensorErrorResult = temp_humi_sensor.readData();
        if(sensorErrorResult == 0)
        {
            // NO ERROR
            // 온도
            printf("No Error \n");
            printf("Temperature(C) ---> %.2fC\n", temp_humi_sensor.ReadTemperature(CELCIUS));       // 섭씨(C)
            printf("Temperature(F) ---> %.2fF \n", temp_humi_sensor.ReadTemperature(FARENHEIT));    // 화씨(F)
            printf("Temperature(K) ---> %.2fK \n", temp_humi_sensor.ReadTemperature(KELVIN));       // 칼빈(K)
            
            //습도
            printf("Humidity(%%) ---> %.2f%%\n", temp_humi_sensor.ReadHumidity());       // 습도
            printf("Dew Point ---> %.2f\n", temp_humi_sensor.CalcdewPoint(temp_humi_sensor.ReadTemperature(CELCIUS), temp_humi_sensor.ReadHumidity()));       // 이슬점(노점)
            
            if(temp_humi_sensor.ReadTemperature(CELCIUS) >= 30) setLedStatus(ledR, 1);
            else setLedStatus(ledR, 0);
            
            if(temp_humi_sensor.ReadHumidity() >= 50) setLedStatus(ledB, 1);
            else setLedStatus(ledB, 0);
            
        }
        else
        {
            // ERROR
            printf("Error \n");
            printf("Error Code ---> %d \n", sensorErrorResult);
        }
        
        wait(5);
        
    }
    
}