#include "mbed.h"
#include "HCSR04.h"

HCSR04 ultrasonic_sensor(D8, D9);
BusOut leds(D2, D3); // D2 --> ledB, D3 --> ledR

int main()
{
    leds = 0;
    float waitVar = 0.0f;
    
    while(1)
    {
        
        leds = 0;
        wait(waitVar);
        
        long distance = ultrasonic_sensor.distance(CM);
        printf("distance ---> %dcm\n", distance);
        
        if(distance <= 60 and distance > 40)            // safety
        {
            leds.write(1);
            waitVar = 0.3f;
        }
        else if(distance <= 40)                         // warning
        {
            leds.write(2);
            waitVar = 0.1f;
        }
        wait(waitVar);
        
    }
    
}
