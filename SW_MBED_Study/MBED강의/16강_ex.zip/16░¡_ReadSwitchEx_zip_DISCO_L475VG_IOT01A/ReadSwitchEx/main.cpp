#include "mbed.h"

DigitalIn read_switch(D5);
BusOut leds(D2, D3);

int main()
{
    
    leds = 0;
    
    while(1)
    {
        int value = read_switch.read();
        printf("read switch value ---> %d \n", value);
        
        /*
        if(value == 0) leds.write(2);
        else leds.write(1);
        */
        
        leds = (value == 0) ? 2 : 1;
        
        wait(0.5);
    }
    
}