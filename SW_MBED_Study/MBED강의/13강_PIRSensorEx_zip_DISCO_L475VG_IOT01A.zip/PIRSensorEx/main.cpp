#include "mbed.h"

DigitalIn pir_sensor(D12);
BusOut leds(D3, D4);

int main()
{
    leds = 0;
    
    int value = 0;
    int i = 0;
    
    while(1)
    {
        value = pir_sensor.read();
        printf("%d sec, pir_sensor value ---> %d \n", i, value);
        wait(1);
        
        
        if(value == 0)
        {
            i = 0;
            leds.write(2);
            printf("Safety\n\n");
        }
        else
        {
            i++;
            leds.write(1);
            printf("Warning\n\n");
        }
    }
    
}