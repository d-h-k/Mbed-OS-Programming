#include "mbed.h"

DigitalOut relay(D15);
AnalogIn cds_sensor(A0);

int main()
{
    relay.write(0);
    
    while(1)
    {        
        relay = cds_sensor >= 0.5f ? 1 : 0;
        printf("cds sensor value ---> %.2f \n", cds_sensor.read());
        wait(1);
    }
    
}