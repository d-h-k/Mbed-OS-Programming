#include "mbed.h"

AnalogIn aiR(A0);
AnalogIn aiG(A1);
AnalogIn aiB(A2);

PwmOut ledR(D3);
PwmOut ledG(D4);
PwmOut ledB(D5);

int main()
{
    ledR.write(0);
    ledG.write(0);
    ledB.write(0);
    
    while(1)
    {
        
        ledR.write(aiR.read());
        ledG.write(aiG.read());
        ledB.write(aiB.read());
        
        printf("aiR value ---> %f \n", aiR.read());
        printf("aiG value ---> %f \n", aiG.read());
        printf("aiB value ---> %f \n", aiB.read());
        
        /*
        for(float f = 0.0f; f <= 1.10f; f += 0.05f)
        {
            ledB.write(1 - f);
            ledR.write(f);
            wait(0.1);
        }
        
        for(float f = 0.0f; f <= 1.10f; f += 0.05f)
        {
            ledR.write(1 - f);
            ledG.write(f);
            wait(0.1);
        }
        
        for(float f = 0.0f; f <= 1.10f; f += 0.05f)
        {
            ledG.write(1 - f);
            ledB.write(f);
            wait(0.1);
        }
        */
        
    }
}