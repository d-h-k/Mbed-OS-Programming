#include "mbed.h"

AnalogIn ai(A0);
AnalogOut ao(D7);

int main()
{
    while(1)
    {
        printf("ai ---> %f \n", ai.read());
        
        ao.write(ai.read());
        
    }
}