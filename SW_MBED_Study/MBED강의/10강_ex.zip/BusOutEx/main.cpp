#include "mbed.h"
#include "cmath"

BusOut outPins(D2, D3, D4, D5, D6);

int main()
{
    
    while(1)
    {
        /*
        //outPins = 1;    // 0000 0001
        outPins = 1 << 0;
        wait(1);
        
        //outPins = 2;    // 0000 0010
        outPins = 1 << 1;
        wait(1);
        
        //outPins = 4;    // 0000 0100
        outPins = 1 << 2;
        wait(1);
        
        //outPins = 8;    // 0000 1000
        outPins = 1 << 3;
        wait(1);
        
        ///outPins = 16;    // 0001 0000
        outPins = 1 << 4;
        wait(1);
        */
        
        /*
        for(int i = 0; i < 5; i++) 
        {
            outPins = 1 << i;
            printf("outPins.read() ---> %d \n", outPins.read());
            wait(1);
        }
        */
        
        for(int i = 0; i < 5; i++)
        {
            outPins = pow(2.0, (double)i);
            printf("outPins.read() ---> %d \n", outPins.read());
            wait(1);
        }
    }
    
}