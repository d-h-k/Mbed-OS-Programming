//#define INITIAL_RUN     //Comment this line if the DS1302 is already running

#include "mbed.h"
#include "DS1302.h"
#include "DHT.h"
#include "TextLCD.h"

DS1302 clk(D6, D7, D8); //SCLK, IO, PTC3

DHT temp_humi_sensor(D15, DHT11);
I2C i2c_lcd(PC_1, PC_0);       // sda, scl
TextLCD_I2C lcd(&i2c_lcd, 0x4E, TextLCD::LCD16x2);

int main() {
     #ifdef INITIAL_RUN
     clk.set_time(1593940920);
     #endif
     
     char storedByte = clk.recallByte(0);
     printf("Stored byte was %d, now increasing by one\r\n", storedByte);
     clk.storeByte(0, storedByte + 1);
     
     int sensorErrorResult = 0;
     
     lcd.setBacklight(TextLCD::LightOn);
     lcd.setCursor(TextLCD::CurOn_BlkOn);
    
     while(1) {
         time_t seconds = clk.time(NULL);
         
         char buffer[32];
         strftime(buffer, 32, "%Y-%m-%d\n%H:%M:%S %p", localtime(&seconds));
         printf("time ---> %s\n", buffer);
         
         lcd.cls();
         lcd.locate(0, 0);
         lcd.printf("%s", buffer);
         
         wait(5);
         
         sensorErrorResult = temp_humi_sensor.readData();
        if(sensorErrorResult == 0)
        {
            // NO ERROR
            // 온도
            printf("No Error \n");
            printf("Temperature(C) ---> %.2fC\n", temp_humi_sensor.ReadTemperature(CELCIUS));       // 섭씨(C)
            
            //습도
            printf("Humidity(%%) ---> %.2f%%\n", temp_humi_sensor.ReadHumidity());       // 습도
            
            lcd.cls();
            lcd.locate(0, 0);
            lcd.printf("Temp(C): %.1fC", temp_humi_sensor.ReadTemperature(CELCIUS));
            
            lcd.locate(0, 1);
            lcd.printf("Humi(%%): %.1f%%", temp_humi_sensor.ReadHumidity());
        }
        else
        {
            // ERROR
            printf("Error \n");
            printf("Error Code ---> %d \n", sensorErrorResult);
            
            lcd.cls();
            lcd.locate(0, 0);
            lcd.printf("Error : %d\n", sensorErrorResult);
        }
        
         wait(5);
     }
}