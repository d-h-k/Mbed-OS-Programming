#include "mbed.h"

DigitalIn flame_sensor(D5);
BusOut leds(D3, D4);

int main()
{
    leds = 0;
    
    while(1)
    {
        
        int value = flame_sensor.read();
        printf("flame_sensor value ---> %d \n", value);
        
        if(value == 0) leds.write(1);
        else leds.write(2);
        
        wait(1);
        
    }
    
}