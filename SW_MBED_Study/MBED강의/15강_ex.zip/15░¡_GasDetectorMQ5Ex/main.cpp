#include "mbed.h"

AnalogIn gas_detector(A0);
BusOut leds(D3, D4);

int converterFloatToInt(float f)
{
    return (int)(f * 100);
}

int main()
{
    leds = 0;
    
    while(1)
    {
        int value = converterFloatToInt(gas_detector.read());
        printf("gas_detector value --> %d%% \n", value);
        
        if(value >= 50) leds.write(1);
        else leds.write(2);  
        
        wait(1);
        
    }
    
}