#include "mbed.h"

AnalogIn soil_moisture(PC_5);
//DigitalOut LedR(D3);
//DigitalOut LedG(D4);
//DigitalOut LedB(D5);

BusOut Leds(D3, D4, D5);

int main()
{
    int value = 0.0f;
    
    //LedR = 0;
    //LedG = 0;
    //LedB = 0;
    
    Leds = 0;
    
    while(1)
    {
        /*
        value = soil_moisture.read();
        printf("Soil Moisture Value = %f \n", value);
        */
        
        value = (int)(100 - soil_moisture.read() * 100);
        printf("Soil Moisture Value = %d%% \n", value);
        
        /*
        if(value >= 60)
        {
            LedR.write(0);
            LedG.write(0);
            LedB.write(1);
        }
        else if(value >= 30)
        {
            LedR.write(0);
            LedG.write(1);
            LedB.write(0);
        }
        else
        {
            LedR.write(1);
            LedG.write(0);
            LedB.write(0);
        }
        */
        
        if(value >= 60) Leds.write(4);
        else if(value >= 30) Leds.write(2);
        else Leds.write(1);
        
        wait(1);
        
    }
    
}