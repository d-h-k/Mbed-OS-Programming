#include "mbed.h"

BusOut sg(D9, D8, D7, D6, D5, D4, D3, D2);
        //dp  g   f   e   d   c   b   a
        
int main()
{
    
    while(1)
    {
        //sg.write(3);     
        sg.write(0x03); //00000011 ---> 0
        wait(1);
        
        sg.write(159);
        //sg.write(0x9F); //10011111 ---> 1
        wait(1);
        
        sg.write(37);
        //sg.write(0x25); //00100101 ---> 2
        wait(1);
        
        sg.write(13);
        //sg.write(0x0D); //00001101 ---> 3
        wait(1);
        
        sg.write(153);
        //sg.write(0x99); //10011001 ---> 4
        wait(1);
        
        sg.write(73);
        //sg.write(0x49); //01001001 ---> 5
        wait(1);
        
        sg.write(65);
        //sg.write(0x41); //01000001 ---> 6
        wait(1);
        
        sg.write(31);
        //sg.write(0x1F); //00011111 ---> 7
        wait(1);
        
        sg.write(1);
        //sg.write(0x01); //00000001 ---> 8
        wait(1);
        
        sg.write(9);
        //sg.write(0x09); //00001001 ---> 9
        wait(1);
        
        sg.write(254);
        //sg.write(0xFE); //11111110 ---> .
        wait(1);
        
        sg.write(0);
        sg.write(0x00); //00000000 ---> all
        wait(1);
    }
    
}