#include "mbed.h"
#include "TextLCD.h"

AnalogIn cds_sensor(A0);

Serial pc(USBTX, USBRX);    // tx, rx
I2C i2c_lcd(D14, D15);       // sda, scl

TextLCD_I2C lcd(&i2c_lcd, 0x4E, TextLCD::LCD16x2);

int main()
{
    
    lcd.setBacklight(TextLCD::LightOff);
    lcd.setCursor(TextLCD::CurOn_BlkOn);
    
    while(1)
    {
        int cdsSensorValue = (int)(100 - cds_sensor.read() * 100);
        printf("cdsSensorValue ---> %d%% \n", cdsSensorValue);
        
        // Clear the screen and locate to 0,0
        lcd.cls();
        
        lcd.locate(0, 0);   // col, row
        lcd.printf("CDS value : ");
        
        lcd.locate(0, 1);   // col, row
        lcd.printf("%.2f / %d%%", cds_sensor.read(), cdsSensorValue);
        
        wait(1);
    }
    
}