#include "mbed.h"
#include "Adafruit_SSD1306.h"
#include "DHT.h"

SPI spi_oled(D11, D12, D13);
Adafruit_SSD1306_Spi oled(spi_oled, D3, D4, D2, 64, 128);
DHT temp_humi_sensor(D15, DHT11);

void printCharacters(char *str)
{
    for(int i = 0; i < str[i]; i++)
    {
        oled.writeChar(str[i]);
    }
}

int main()
{
    oled.clearDisplay();
    oled.setTextSize(1);
    oled.setTextCursor(0, 10);
    //printCharacters("Hello!!");
    oled.writeChar('H');
    oled.writeChar('e');
    oled.writeChar('l');
    oled.writeChar('l');
    oled.writeChar('0');
    
    oled.setTextSize(2);
    oled.setTextCursor(0, 20);
    oled.writeChar('H');
    oled.writeChar('e');
    oled.writeChar('l');
    oled.writeChar('l');
    oled.writeChar('0');
    
    oled.setTextSize(3);
    oled.setTextCursor(0, 36);
    oled.printf(">%d<", 3);
    
    oled.display();
    
    int sensingErrorResult = 0;
    
    while(1)
    {
        
        oled.clearDisplay();
        oled.setTextSize(1);
        oled.setTextCursor(0, 10);
        
        sensingErrorResult = temp_humi_sensor.readData();
        if(sensingErrorResult == 0)
        {
            printf("No error \n");
            printf("Temperature(C) ---> %.2fC\n", temp_humi_sensor.ReadTemperature(CELCIUS));      // 섭씨
            printf("Temperature(F) ---> %.2fF\n", temp_humi_sensor.ReadTemperature(FARENHEIT));    // 화씨
            printf("Temperature(K) ---> %.2fK\n", temp_humi_sensor.ReadTemperature(KELVIN));       // 켈빈
            
            printf("Humidity(%%) ---> %.2f%%\n", temp_humi_sensor.ReadHumidity());
            printf("Dew point ---> %.2fC\n",temp_humi_sensor.CalcdewPoint(temp_humi_sensor.ReadTemperature(CELCIUS), temp_humi_sensor.ReadHumidity()));
            
            oled.printf("Temp(C) : %0.2fC\n", temp_humi_sensor.ReadTemperature(CELCIUS));
            oled.printf("Humi(%%) : %.2f%%\n", temp_humi_sensor.ReadHumidity());
            oled.printf("DewPoint : %.2fC\n", temp_humi_sensor.CalcdewPoint(temp_humi_sensor.ReadTemperature(CELCIUS), temp_humi_sensor.ReadHumidity()));
        }
        else
        {
            printf("Error \n");
            printf("SensingErrorResult ---------------> %d \n", sensingErrorResult);
            
            oled.printf("Error \n");
        }
        
        oled.display();
        
        wait(15);
        
    }
    
}