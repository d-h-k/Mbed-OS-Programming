#include "mbed.h"

BusIn btns(D1, D2, D3, D4);
BusOut leds(LED1, LED2, LED3, LED4);

int main()
{
    
    btns.mode(PullDown);
    
    while(1)
    {
        printf("btns.read() value ---> %d \n", btns.read());
        leds = btns.read();
    }
    
}