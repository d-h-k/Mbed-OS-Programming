#include "mbed.h"
#include "Sseg.h"

Sseg sg(D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12, D13);
      //a   b   c   d   e   f   g   dp  d1   d2   d3   d4
      
AnalogIn cds_sensor(A0);

int main()
{
    
    sg.setKcommon();
    sg.begin();
    
    sg.writeNum(9876);
    
    while(1)
    {
        //sg.update();
        //wait_ms(5);
        
        int cdsSensorPercent = (int)(100 - (cds_sensor.read() * 100));
        
        sg.writeNum(cdsSensorPercent);
        
        sg.update();
        wait_ms(5);
        
    }
    
}