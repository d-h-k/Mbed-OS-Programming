#include "mbed.h"

DigitalOut led_gre_d2(D2);
DigitalOut led_red_d3(D3);
DigitalOut led_blu_d4(D4);

//DigitalIn btn_red_d8(D8);

InterruptIn btn_red_d8(D8);
InterruptIn btn_blu_d9(D9);

void btnRedD8FallFun()
{
    led_red_d3 = 1;
}

void btnRedD8RiseFun()
{
    led_red_d3 = 0;
}

void btnBluD9FallFun()
{
    led_blu_d4 = 0;
}

void btnBluD9RiseFun()
{
    led_blu_d4 = 1;
}

int main()
{
    
    led_gre_d2 = 0;
    
    
    btn_red_d8.mode(PullUp); //normal ---> 1
    btn_blu_d9.mode(PullDown); //normal ---> 0
    
    btn_red_d8.fall(btnRedD8FallFun);      // 눌렀을때
    btn_red_d8.rise(btnRedD8RiseFun);      // 누르지 않았을때
    
    btn_blu_d9.fall(btnBluD9FallFun);
    btn_blu_d9.rise(btnBluD9RiseFun); 
    
    while(1)
    {
        
        led_gre_d2 = !led_gre_d2;
        wait(1);
        
        //if(btn_red_d8.read() == 1) led_red_d3 = 0;
        //else led_red_d3 = 1;
        
        //printf("btn_red_d8 STATUS ---> %d \n", btn_red_d8.read());
        
    }
    
}