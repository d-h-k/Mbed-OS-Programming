#include "mbed.h"

AnalogOut ao(LED1);

int main()
{
    
    ao.write(0.0f);
    
    while(1)
    {
        for(float f = 0.0f; f < 1.0f; f += 0.05f)
        {
            ao.write(f);
            printf("ao status ---> %f\n", ao.read());
            wait(0.1);
        }
        
        for(float f = 0.0f; f < 1.0f; f += 0.05f)
        {
            ao.write(1 - f);
            printf("ao status ---> %f\n", ao.read());
            wait(0.1);
        }
    }
    
}