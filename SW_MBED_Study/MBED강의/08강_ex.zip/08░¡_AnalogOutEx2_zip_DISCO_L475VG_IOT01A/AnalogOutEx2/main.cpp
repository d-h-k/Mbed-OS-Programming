#include "mbed.h"

DigitalIn btn(USER_BUTTON);
AnalogOut ledD7(D7);

int main()
{
    
    float values[] = {0.0f, 0.1f, 0.2f, 0.3f, 0.4f, 0.5f, 0.6f, 0.7f, 0.8f, 0.9f, 1.0f};
    int index = 0;
    
    ledD7.write(0);
    
    while(1)
    {
        printf("btn vlaue ---> %d\n", btn.read());
        
        if(btn.read() == 0)
        {
            ledD7.write(values[index]);
            printf("ledD7 ---> %f\n", ledD7.read());   
            
            //if(ledD7.read() >= 1.0f) ledD7 = 0.0f;
            
            index++;
            if (index >= 11) index = 0;
        }
        
        wait(0.1);
    }   
}