#include "mbed.h"
#include "TextLCD.h"

Serial pc(USBTX, USBRX); // tx, rx
TextLCD lcd(D2, D3, D4, D5, D6, D7);

AnalogIn cds_sensor(A0);

int main()
{
    
    pc.printf("lcd.columns(): %d, lcd.rows(): %d", lcd.columns(), lcd.rows());
    
    lcd.setBacklight(TextLCD::LightOn);
    lcd.setCursor(TextLCD::CurOn_BlkOn);
    
    lcd.cls();
    
    lcd.printf("Hello mbed!\n");
    lcd.printf("Hello LCD!");
    
    while(1)
    {
        int cds_sensor_per = (int)(100 - cds_sensor.read() * 100);
        printf("cds_sensor value ---> %f\n", cds_sensor.read());
        printf("cds_sensor value ---> %d%%\n", cds_sensor_per);
        
        lcd.cls();
        
        lcd.locate(0, 0);
        lcd.printf("CDS Value:");
        
        lcd.locate(0, 1);
        lcd.printf("%.2f / %d%%", cds_sensor.read(), cds_sensor_per);
        
        wait(3);
        
        
    }
    
}
