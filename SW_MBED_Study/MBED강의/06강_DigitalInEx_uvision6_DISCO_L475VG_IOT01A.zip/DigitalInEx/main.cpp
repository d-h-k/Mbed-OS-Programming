#include "mbed.h"

DigitalOut myLed(LED1);
DigitalIn myBtn(D3, PullUp);

int main()
{
    while(1)
    {
        myLed = !myBtn;
        printf("myBtn.read() ---> %d \n", myBtn.read()); 
    }
        
}