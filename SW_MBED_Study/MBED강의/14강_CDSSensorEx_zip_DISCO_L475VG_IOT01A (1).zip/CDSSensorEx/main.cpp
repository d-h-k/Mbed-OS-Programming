#include "mbed.h"

AnalogIn cds_sensor(A0);
//DigitalOut led(D3);
PwmOut led(D3);

int convertFloatToInt(float f) { return (int)(100 - f * 100); }

int main()
{
    
    while(1)
    {
        /*
        printf("cds_sensor value ---> %f \n", cds_sensor.read());
        wait(1);
        */
        
        /*
        int cdsSensorValuePercent = convertFloatToInt(cds_sensor.read());
        printf("cdsSensorValuePercent ---> %d%% \n", cdsSensorValuePercent);
        wait(1);
        */
        
        /*
        led = cds_sensor >= 0.5f ? 1 : 0;
        printf("cds_sensor value ---> %f \n", cds_sensor.read());
        wait(1);
        */
        
        //led.write(cds_sensor.read());
        led = cds_sensor;
        printf("cds_sensor value ---> %f \n", cds_sensor.read());
        wait(1);
        
        
        
    }
    
}