#include "mbed.h"
#include "rtos.h"

DigitalOut ledR(D2);
DigitalOut ledG(D3);

Thread thread;

void threadForLeds()
{
    /*
    while(1)
    {
        uint32_t data = ThisThread::flags_wait_any(0x03);
        
        if(data & 0x01)
        {
            ledR = !ledR;
        }
        
        if(data & 0x02)
        {
            ledG = !ledG;
        }
    }
    */
    
    while(!ThisThread::flags_wait_any_for(0x01, 2000))
    {
        ledR = !ledR;
        ledG = !ledG;
    }
    
}

int main()
{
    ledR = 1;
    ledG = 0;
    
    thread.start(threadForLeds);
    
    ThisThread::sleep_for(10000);
    thread.flags_set(0x01);
    thread.join();
    
    while(1)
    {
        
        //thread.flags_set(0x01); // ledR
        //thread.flags_set(0x02); // ledG
        //ThisThread::sleep_for(2000); // wait_ms(2000);
        
    }
}