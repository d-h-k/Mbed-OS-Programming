#include "mbed.h"
#include "TextLCD.h"

Serial pc(USBTX, USBRX, 9600);
I2C i2c_lcd(PC_1, PC_0);       // sda, scl
TextLCD_I2C lcd(&i2c_lcd, 0x4E, TextLCD::LCD16x2);

DigitalOut led_red_d2(D2);
AnalogIn cds_sensor(A0);

Timer timer1;
Timer timer2;
Timer timer3;

int main()
{
    lcd.setBacklight(TextLCD::LightOn);
    lcd.setCursor(TextLCD::CurOn_BlkOn);
    
    timer2.start();
    timer3.start();
    
    while(1)
    {
        /*
        timer1.start();
        pc.printf("Hello mbed!!\n");
        timer1.stop();
        pc.printf("timer1 read ---> %f\n", timer1.read());
        timer1.reset();
        */
        
        
        if(pc.readable())
        {
            char c = pc.getc();
            printf("input data ---> %c\n", c);
            
            if(c == 't')
            {
                timer1.reset();
                timer1.start();
            }
            else if(c == 's')
            {
                timer1.stop();
            }
            else if(c == 'i')
            {
                timer1.reset();
            }
        }
        
        lcd.cls();
        lcd.locate(0, 0);
        lcd.printf("Stopwatch");
        
        lcd.locate(0, 1);
        lcd.printf("%f sec", timer1.read());
        wait(0.5);
        
        
        //led_red_d2 = !led_red_d2;
        //wait(0.5);
        
        if(timer2.read() >= 0.5)
        {
            led_red_d2 = !led_red_d2;
            timer2.reset();
        }
        
        
        //printf("cds_sensor ---> %.2f \n", cds_sensor.read());
        //wait(3);
        
        if(timer3.read() >= 3)
        {
            printf("cds_sensor ---> %.2f \n", cds_sensor.read());
            timer3.reset();
        }
        
    }
    
}