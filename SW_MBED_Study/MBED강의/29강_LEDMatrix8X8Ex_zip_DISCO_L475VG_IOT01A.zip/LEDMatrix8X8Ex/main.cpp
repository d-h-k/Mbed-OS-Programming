#include "mbed.h"

BusOut led_matrix_rows(D2, D3, D4, D5, D6, D7, D8);
BusOut led_matrix_clos(D10, D11, D12, D13, A0, A1, A2, A3);

int main()
{
    
    float waitNum = 0.001f;
    
    while(1)
    {
        /*
        led_matrix_rows.write(0b00000000);
        led_matrix_clos.write(0b11111111);
        wait(1);
        
        led_matrix_rows.write(0b00000001);
        led_matrix_clos.write(0b11111110);
        wait(1);
        */
        
        //'X'
        led_matrix_rows.write(0b00000001);
        led_matrix_clos.write(0b01111110);
        wait(waitNum);
        
        led_matrix_rows.write(0b00000010);
        led_matrix_clos.write(0b10111101);
        wait(waitNum);
        
        led_matrix_rows.write(0b00000100);
        led_matrix_clos.write(0b11011011);
        wait(waitNum);
        
        led_matrix_rows.write(0b00001000);
        led_matrix_clos.write(0b11100111);
        wait(waitNum);
        
        led_matrix_rows.write(0b00010000);
        led_matrix_clos.write(0b11100111);
        wait(waitNum);
        
        led_matrix_rows.write(0b00100000);
        led_matrix_clos.write(0b11011011);
        wait(waitNum);
        
        led_matrix_rows.write(0b01000000);
        led_matrix_clos.write(0b10111101);
        wait(waitNum);
        
        led_matrix_rows.write(0b10000000);
        led_matrix_clos.write(0b01111110);
        wait(waitNum);
    }
    
}