/*
############################################
##           sMotor v0.1 Test Program     ##
##          created by Samuel Matildes    ##
############################################
        ---- sam.naeec@gmail.com -----
This library was made for 4-Phase Stepper Motors
I don't take any resposability for the damage caused to your equipment.
 
*/
 
#include "mbed.h"
#include "sMotor.h"
 
Serial pc(USBTX, USBRX);
sMotor motor(D2, D3, D4, D5); // creates new stepper motor: IN1, IN2, IN3, IN4
 
int step_speed = 1200 ; // set default motor speed
int numstep = 512 ; // defines full turn of 360 degree
//you might want to calibrate this value according to your motor
 
 
int main() {
 
    //Credits
    printf("4 Phase Stepper Motor v0.1 - Test Program\n");
    printf("developed by Samuel Matildes\n");
    printf("\n");
 
    // Screen Menu
    printf("Default Speed: %d\n\r",step_speed);
    printf("1- 360 degree clockwise step\n");
    printf("2- 360 degree anticlockwise step\n");
    printf("3- 180 degree clockwise step\n");
    printf("4- 180 degree anticlockwise step\n");
    printf("5- Change Speed\n");
 
    while (1) {
 
        if (pc.readable()) { // checks for serial
            
            char c = pc.getc();
            
            if (c=='1')
                motor.step(numstep,0,step_speed); // number of steps, direction, speed
 
            if (c=='2')
                motor.step(numstep,1,step_speed);
 
            if (c=='3')
                motor.step(numstep/2,0,step_speed);
 
            if (c=='4')
                motor.step(numstep/2,1,step_speed);
 
            if (c=='5') {
                printf("Current Speed: %d\n\r", step_speed);
                printf("New speed: \n");
                pc.scanf("%d",&step_speed); // sets new speed
            }
        }
    }
}