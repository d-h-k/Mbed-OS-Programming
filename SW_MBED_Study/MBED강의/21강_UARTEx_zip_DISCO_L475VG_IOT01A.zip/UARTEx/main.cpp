#include "mbed.h"

//Serial pc(STDIO_UART_TX, STDIO_UART_RX, 115200);
//Serial pc(SERIAL_TX, SERIAL_UART_RX, 115200);
Serial pc(USBTX, USBRX, 115200);

//DigitalOut ledR(D2);
BusOut leds(D2, D3, D4);

int main()
{
    //ledR = 0;
    leds = 0;
    
    while(1)
    {
        
        //printf("Hello~ \n");
        //wait(1);
        
        //pc.printf("Hello~ \n");
        //wait(1);
        
        
        //pc.putc(pc.getc());
        
        /*
        pc.putc(pc.getc());
        ledR = !ledR;
        wait(1);
        */
        
        /*
        if(pc.readable()) pc.putc(pc.getc());
        ledR = !ledR;
        wait(1);
        */
        
        if(pc.readable())
        {
            char c = pc.getc();
            if(c == 'r') leds = 1;
            else if(c == 'g') leds = 2;
            else if(c == 'b') leds = 4;
            else leds = 0;
            
            pc.putc(c);
            pc.putc('\n');
        }
        
    }
    
}